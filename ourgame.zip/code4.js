gdjs.Level_324Code = {};
gdjs.Level_324Code.localVariables = [];
gdjs.Level_324Code.GDTheEndObjects1= [];
gdjs.Level_324Code.GDTheEndObjects2= [];
gdjs.Level_324Code.GDBackgroundObjects1= [];
gdjs.Level_324Code.GDBackgroundObjects2= [];
gdjs.Level_324Code.GDBlackBarsObjects1= [];
gdjs.Level_324Code.GDBlackBarsObjects2= [];
gdjs.Level_324Code.GDNestObjects1= [];
gdjs.Level_324Code.GDNestObjects2= [];
gdjs.Level_324Code.GDDuckArtworkObjects1= [];
gdjs.Level_324Code.GDDuckArtworkObjects2= [];
gdjs.Level_324Code.GDLadyDuckObjects1= [];
gdjs.Level_324Code.GDLadyDuckObjects2= [];
gdjs.Level_324Code.GDHeartObjects1= [];
gdjs.Level_324Code.GDHeartObjects2= [];


gdjs.Level_324Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "TheEnd.mp3", true, 100, 1);
}}

}


};

gdjs.Level_324Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level_324Code.GDTheEndObjects1.length = 0;
gdjs.Level_324Code.GDTheEndObjects2.length = 0;
gdjs.Level_324Code.GDBackgroundObjects1.length = 0;
gdjs.Level_324Code.GDBackgroundObjects2.length = 0;
gdjs.Level_324Code.GDBlackBarsObjects1.length = 0;
gdjs.Level_324Code.GDBlackBarsObjects2.length = 0;
gdjs.Level_324Code.GDNestObjects1.length = 0;
gdjs.Level_324Code.GDNestObjects2.length = 0;
gdjs.Level_324Code.GDDuckArtworkObjects1.length = 0;
gdjs.Level_324Code.GDDuckArtworkObjects2.length = 0;
gdjs.Level_324Code.GDLadyDuckObjects1.length = 0;
gdjs.Level_324Code.GDLadyDuckObjects2.length = 0;
gdjs.Level_324Code.GDHeartObjects1.length = 0;
gdjs.Level_324Code.GDHeartObjects2.length = 0;

gdjs.Level_324Code.eventsList0(runtimeScene);
gdjs.Level_324Code.GDTheEndObjects1.length = 0;
gdjs.Level_324Code.GDTheEndObjects2.length = 0;
gdjs.Level_324Code.GDBackgroundObjects1.length = 0;
gdjs.Level_324Code.GDBackgroundObjects2.length = 0;
gdjs.Level_324Code.GDBlackBarsObjects1.length = 0;
gdjs.Level_324Code.GDBlackBarsObjects2.length = 0;
gdjs.Level_324Code.GDNestObjects1.length = 0;
gdjs.Level_324Code.GDNestObjects2.length = 0;
gdjs.Level_324Code.GDDuckArtworkObjects1.length = 0;
gdjs.Level_324Code.GDDuckArtworkObjects2.length = 0;
gdjs.Level_324Code.GDLadyDuckObjects1.length = 0;
gdjs.Level_324Code.GDLadyDuckObjects2.length = 0;
gdjs.Level_324Code.GDHeartObjects1.length = 0;
gdjs.Level_324Code.GDHeartObjects2.length = 0;


return;

}

gdjs['Level_324Code'] = gdjs.Level_324Code;
